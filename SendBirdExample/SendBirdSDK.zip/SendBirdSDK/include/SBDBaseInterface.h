#pragma once

class SBDBaseInterface {
public:
	virtual ~SBDBaseInterface() = 0;
};
